
export function laNow() {
  return typeof performance !== "undefined" ? performance.now() : Date.now();
}

export function laCost(f, itemId, x, y, w, h, leader) {
  const v = f({ itemId, box: { x, y, w, h }, leader });
  if (typeof v !== "number" || !Number.isFinite(v)) {
    throw new TypeError(
      `label-anything: the cost callback must return a finite number (got ${String(v)} for item "${itemId}")`,
    );
  }
  return v;
}

export function laMeasure(f, text, family, weight, italic, size) {
  const m = f(text, { family, weight, italic, size });
  if (m === null || m === undefined) return undefined;
  const width = m.width, ascent = m.ascent, descent = m.descent;
  if (!Number.isFinite(width) || !Number.isFinite(ascent) || !Number.isFinite(descent)) {
    throw new TypeError(
      "label-anything: the measure callback must return null or {width, ascent, descent} with finite numbers",
    );
  }
  return [width, ascent, descent];
}
