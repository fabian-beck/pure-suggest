/**
 * Static candidate cost and hard feasibility (spec §8, §6.7); port of
 * `rust/crates/la-core/src/cost.rs`.
 *
 * @module
 */

import {
  BLOCK_EDGE,
  BLOCK_ITEMS,
  BLOCK_LABELS,
  BLOCK_REGIONS,
  type Block,
  type Cand,
  Kind,
  type Leader,
  WARM_MARGIN,
} from "./candidates.js";
import type { Env } from "./env.js";
import type { SplitScratch } from "./grid/regions.js";
import { EPS, P, Rect, segOverlapsRectXY } from "./geom/index.js";
import type { Variant } from "./labels.js";
import { clampf, maxf, minf } from "./math.js";
import type { Item, Model } from "./model/index.js";
import { AvoidKind, type Obstacles, primDistSegment, primOverlapsRect } from "./obstacles.js";
import { IdList } from "./spatial.js";

/** Named cost terms (for `cost_breakdown`), in insertion order. */
export type Breakdown = [string, number][];

class Acc {
  cost = 0;
  feasible = true;
  relaxed = true;
  relaxCost = 0;
  blocked: Block | null = null;
  breakdown: Breakdown | null = null;

  add(name: string, v: number): void {
    if (v === 0) return;
    this.cost += v;
    const b = this.breakdown;
    if (b !== null) {
      const e = b.find((x) => x[0] === name);
      if (e !== undefined) e[1] += v;
      else b.push([name, v]);
    }
  }

  /** `add` for the term `prefix` + `name`, a name built only for a breakdown. */
  addNamed(prefix: string, name: string, v: number): void {
    if (this.breakdown !== null) this.add(prefix + name, v);
    else if (v !== 0) this.cost += v;
  }

  violate(why: Block, relaxable: boolean, extra: number): void {
    if (this.feasible) {
      this.feasible = false;
      this.blocked = why;
    }
    if (relaxable) this.relaxCost += extra;
    else this.relaxed = false;
  }

  /**
   * With `quick = softOk` (not null): whether the candidate can no longer be used — not even
   * relaxed, or infeasible where relaxed candidates do not count.
   */
  unusable(quick: boolean | null): boolean {
    return quick !== null && (!this.relaxed || (!quick && !this.feasible));
  }
}

/**
 * `crowded`: whether the mark of another item (not of the item's group) comes closer than
 * `stub_reach` to the label box `r` of `item`: the label could be read as that item's (spec
 * §6.9). `buf` is scratch space for the item query.
 */
export function crowded(model: Model, obs: Obstacles, item: Item, r: Rect, buf: IdList): boolean {
  const reach = item.len.stubReach;
  // a label against a mark larger than its font size reads as attached to it
  const b = item.shape.bbox();
  if (reach <= 0 || maxf(b.w(), b.h()) > item.em()) return false;
  const i = item.index;
  obs.itemIndex.query(r.inflate(reach), buf);
  for (let q = 0; q < buf.len; q++) {
    const j = buf.get(q);
    if (j !== i && model.groupRep(j) !== i && model.items[j]!.shape.distRect(r) < reach) return true;
  }
  return false;
}

/**
 * How squarely the point `p` lies beside a side of `r`, where a label of a mark at `p` would
 * go: 1 straight across a side (or inside `r`), 0 on the diagonal of a corner, and
 * `|dx² − dy²| / (dx² + dy²)` for the offset `(dx, dy)` of `p` from `r` (spec §4.4).
 */
export function facing(r: Rect, p: P): number {
  const dx = p.x < r.x0 ? r.x0 - p.x : p.x > r.x1 ? p.x - r.x1 : 0;
  const dy = p.y < r.y0 ? r.y0 - p.y : p.y > r.y1 ? p.y - r.y1 : 0;
  const s = dx * dx + dy * dy;
  return s > 0 ? Math.abs(dx * dx - dy * dy) / s : 1;
}

/**
 * The area of the label of `c` that `f` reports as covered: `f` of its box, or for a
 * turned label the sum over the boxes of its cover, scaled to the label's area.
 */
function covered(c: Cand, f: (b: Rect) => number): number {
  const t = c.turn;
  if (t === null) return f(c.rect);
  let sum = 0.0;
  let all = 0.0;
  for (const b of t.cover) {
    sum += f(b);
    all += b.area();
  }
  return all > 0.0 ? (sum * t.upright.area()) / all : 0.0;
}

/** Whether `f` holds for one of the boxes of the label of `c`. */
function anyBox(c: Cand, f: (b: Rect) => boolean): boolean {
  const t = c.turn;
  if (t === null) return f(c.rect);
  for (const b of t.cover) if (f(b)) return true;
  return false;
}

function finish(c: Cand, acc: Acc): void {
  c.evaluated = true;
  c.cost = acc.cost;
  c.feasible = acc.feasible;
  c.relaxed = acc.relaxed;
  c.relaxCost = acc.relaxCost;
  c.blocked = acc.blocked;
}

/** Evaluates static costs. Holds scratch buffers. */
export class Evaluator {
  private readonly buf = new IdList();
  private readonly buf2 = new IdList();
  /** Per-region areas of a label box. */
  private readonly split: SplitScratch = { ids: [], areas: [] };
  /** `softOk` while {@link evalUsable} runs, else null. */
  private quick: boolean | null = null;
  /**
   * Less important items whose marks a label covers, while {@link evalUsable} runs: their
   * coverage is summed once the hard rules let the label be used.
   */
  private readonly lower: number[] = [];

  constructor(
    readonly model: Model,
    readonly obs: Obstacles,
    readonly env: Env,
  ) {}

  /**
   * {@link eval} for a caller that keeps a candidate only when it is usable (feasible, or
   * relaxed with `softOk`): the evaluation stops at the first violation that leaves it
   * unusable, so the cost of a candidate it returns unusable is partial.
   */
  evalUsable(c: Cand, v: Variant, softOk: boolean): void {
    this.quick = softOk;
    this.eval(c, v, null);
    this.quick = null;
  }

  /** Fill `c.cost`, `c.feasible`, `c.relaxed`, `c.relaxCost`, `c.blocked`. */
  eval(c: Cand, v: Variant, breakdown: Breakdown | null = null): void {
    const model = this.model;
    const obs = this.obs;
    const i = c.item;
    const item = model.items[i]!;
    const em = item.em();
    const r = c.rect;
    // a turned label is tested as the boxes of its cover (spec §6.5)
    const turned = c.turn !== null;
    const area = maxf(r.area(), 1e-9);
    // coverage costs count covered em², whatever the label's size (spec §8)
    const em2 = em * em;
    const w = model.weights;
    const dy = obs.dynamic;
    const softW = model.degrade.softOverlapWeight;
    const quick = this.quick;
    const acc = new Acc();
    acc.breakdown = breakdown;

    // 1. label area (canvas_edge)
    const la = obs.labelArea;
    if (la !== null && !la.containsRect(r)) {
      const e = dy.labelEdge;
      if (e.kind === AvoidKind.Hard) acc.violate(BLOCK_EDGE, false, 0);
      else if (e.kind === AvoidKind.Soft) acc.add("canvas_edge", (e.w * (area - la.overlapArea(r))) / em2);
    }
    if (!acc.relaxed) return finish(c, acc);
    // 2. items (exact); one query serves the buffer ring and the ambiguity term
    const ring = r.inflate(item.len.buffer);
    const gapGuess = item.len.offset + 0.5 * em;
    const margin = c.warm ? WARM_MARGIN * item.len.margin : item.len.margin;
    // a label without a distant leader comes no closer to another item's mark than to its
    // own, and without a stub it is nearer to its own by its margin (spec §4.4)
    const nearRule =
      model.placement.ownNearest && c.kind !== Kind.Internal && (c.leaders.length === 0 || c.hasStub());
    const dOwn = nearRule ? item.shape.distRect(r) : 0;
    const clear = nearRule && !c.hasStub() ? margin : 0;
    // a mark that lies more squarely beside a side of the label than its own, where its own
    // label would go, must be farther still: up to the side margin
    const side = clear > 0 ? maxf(c.warm ? WARM_MARGIN * item.len.sideMargin : item.len.sideMargin, clear) : 0;
    const ownFacing = side > clear ? facing(r, item.shape.reference()) : 1;
    // no other mark needs more than the side margin's share the own mark leaves
    const reach = maxf(
      maxf(item.len.buffer > gapGuess ? item.len.buffer : gapGuess, margin),
      dOwn + clear + (side - clear) * (1 - ownFacing),
    );
    const buf = this.buf;
    obs.itemIndex.query(r.inflate(reach), buf);
    const labelItemsHard = dy.labelItems.kind === AvoidKind.Hard;
    // the marks of less important items follow `lower_items` where it differs from `items`
    const lowerRule = !dy.labelLower.equals(dy.labelItems);
    const labelLowerHard = dy.labelLower.isHard();
    let lowerCov = 0;
    const lowerJs = this.lower;
    lowerJs.length = 0;
    let otherFound = false;
    for (let q = 0; q < buf.len; q++) {
      const j = buf.get(q);
      const sj = model.items[j]!.shape;
      const lower = lowerRule && j !== i && model.isLower(i, j);
      if (lower) {
        if (quick !== null) lowerJs.push(j);
        else lowerCov += obs.ownCovered(j, r);
      }
      if (j === i) {
        if (c.kind === Kind.Internal) continue;
        const om = dy.ownMark;
        if (om.kind === "hard") {
          if (c.labelOverlapsShape(sj)) acc.violate(BLOCK_ITEMS, false, 0);
        } else if (om.kind === "partial") {
          if (c.labelOverlapsShape(sj)) {
            const own = obs.own(i);
            const frac = own[1].coveredArea(own[0], r) / maxf(sj.area(), 1e-9);
            if (frac > om.f) acc.violate(BLOCK_ITEMS, false, 0);
          }
        }
        if (acc.unusable(quick)) return finish(c, acc);
        continue;
      }
      otherFound = true;
      const hard = lower ? labelLowerHard : labelItemsHard;
      let d: number;
      if (hard) {
        if (c.labelOverlapsShape(sj)) {
          acc.violate(BLOCK_ITEMS, false, 0);
          if (acc.unusable(quick)) return finish(c, acc);
          continue;
        }
        d = c.distShape(sj);
        // the margin (up to rounding), but never more than the mark keeps from the own
        // mark's box
        if (margin > EPS && d < margin - EPS && d < sj.distRect(item.shape.bbox())) {
          acc.violate(BLOCK_ITEMS, false, 0);
          if (acc.unusable(quick)) return finish(c, acc);
        }
      } else {
        // of the marks the label may cover, that of a less important item (`lower_items`
        // given and not hard) competes with the own mark unless the label hides it entirely:
        // no reader takes a hidden mark for the label's, and its item goes unlabeled. Only
        // for an item with a place beside its mark that hides or keeps clear of such marks
        // (spec §4.4)
        if (
          !nearRule ||
          obs.lowerRule[i] !== true ||
          !model.isLower(i, j) ||
          (r.containsRect(sj.bbox()) && c.labelOverlapsShape(sj))
        ) {
          continue;
        }
        d = c.distShape(sj);
      }
      // nearer to the label than its own mark, or, without a stub, not a margin farther, up to
      // the side margin for the point's mark of an item it may not cover that lies more
      // squarely beside a side than the own (at most as far as the two marks' reference
      // points lie apart; the marks of the item's group aside)
      let sep = 0;
      if (clear > 0) {
        const need =
          hard && side > clear && model.items[j]!.area === null
            ? clear + (side - clear) * maxf(facing(r, sj.reference()) - ownFacing, 0)
            : clear;
        sep = minf(need, sj.reference().dist(item.shape.reference()));
      }
      if (nearRule && d < dOwn + sep - EPS && model.groupRep(j) !== i) {
        acc.violate(BLOCK_ITEMS, false, 0);
        if (acc.unusable(quick)) return finish(c, acc);
      }
    }
    // nor to an unlabeled point, where some place beside the mark keeps clear of them (spec
    // §4.4)
    if (nearRule && acc.feasible && obs.pointsRule[i] === true) {
      const pc = obs.pointNearer(item, r, dOwn, clear);
      if (pc !== null) {
        acc.violate(pc, false, 0);
        if (acc.unusable(quick)) return finish(c, acc);
      }
    }
    // (in the order of the query, as above)
    for (const j of lowerJs) lowerCov += obs.ownCovered(j, r);
    if (dy.labelItems.kind === AvoidKind.Soft) {
      const cov = turned ? covered(c, (b) => obs.otherItemsCovered(i, b)) : obs.otherItemsCovered(i, r);
      acc.add("items", (dy.labelItems.w * (lowerRule ? maxf(cov - lowerCov, 0) : cov)) / em2);
    }
    if (lowerRule && dy.labelLower.kind === AvoidKind.Soft) acc.add("lower_items", (dy.labelLower.w * lowerCov) / em2);
    // the ring only sees other items when the item query found any besides the own
    if (dy.bufferItems > 0 && otherFound) {
      const ringArea = maxf(ring.area() - area, 1e-9);
      const cov = maxf(obs.otherItemsCovered(i, ring) - obs.otherItemsCovered(i, r), 0);
      acc.add("buffer:items", (dy.bufferItems * cov) / ringArea);
    }
    if (!acc.relaxed) return finish(c, acc);
    // 3. static classes (an internal label of a mark covers only the mark, which hides what
    // lies under it: no soft coverage costs)
    const onMark = c.kind === Kind.Internal && item.area === null;
    let hardPrimsChecked = false;
    const classes = obs.classes;
    const grid = obs.grid;
    for (let ci = 0; ci < classes.length; ci++) {
      const cl = classes[ci]!;
      const sat = cl.sat;
      if (sat === null) continue;
      const lk = cl.label.kind;
      if (lk === AvoidKind.Hard) {
        let hit = false;
        if (cl.hasRaster) hit = turned ? anyBox(c, (b) => sat.any(grid, b)) : sat.any(grid, r);
        else if (cl.hasPrims) {
          const buf2 = this.buf2;
          if (!hardPrimsChecked) {
            obs.primIndex().query(r, buf2);
            hardPrimsChecked = true;
          }
          const prims = obs.prims();
          for (let q = 0; q < buf2.len; q++) {
            const pr = prims[buf2.get(q)]!;
            if (pr[0] === ci && (turned ? anyBox(c, (b) => primOverlapsRect(pr[1], b)) : primOverlapsRect(pr[1], r))) {
              hit = true;
              break;
            }
          }
        }
        if (hit) {
          const cov = turned ? covered(c, (b) => sat.coveredArea(grid, b)) : sat.coveredArea(grid, r);
          acc.violate(ci, cl.relaxable, (softW * cov) / em2);
          if (acc.unusable(quick)) return finish(c, acc);
        }
      } else if (lk === AvoidKind.Soft) {
        if (!onMark && (turned ? anyBox(c, (b) => sat.any(grid, b)) : sat.any(grid, r))) {
          const cov = turned ? covered(c, (b) => sat.coveredArea(grid, b)) : sat.coveredArea(grid, r);
          acc.add(cl.name, (cl.label.w * cov) / em2);
        }
      }
      if (cl.buffer > 0 && sat.any(grid, ring)) {
        const ringArea = maxf(ring.area() - area, 1e-9);
        const cov = maxf(sat.coveredArea(grid, ring) - sat.coveredArea(grid, r), 0);
        acc.addNamed("buffer:", cl.name, (cl.buffer * cov) / ringArea);
      }
    }
    if (!acc.relaxed) return finish(c, acc);
    // 3b. backdrop contrast: the luma variance under the box (none on a mark)
    const bd = obs.backdrop;
    if (bd !== null && !onMark) {
      const cell = bd.grid.cell;
      const d = bd.deviation(r);
      acc.add("contrast", (w.contrast * ((4 * d * (cell * cell)) / 65025)) / em2);
    }
    // 3c. regions: a label across a border, in a region other than its item's (none on a mark)
    const rm = obs.regions;
    if (rm !== null && !onMark) {
      const sp = rm.split(r, obs.home[i]!, this.split);
      // a label that names a region by where it lies (an area's, not inside it, or one on a
      // leader) lies mostly at home or in open space. Not so the box of a pinned solve: the
      // view has moved, and with it the map's cells under a box that had its place
      if (sp.foreign > model.placement.maxForeign * sp.area && c.kind !== Kind.Internal && (item.area !== null || c.leaders.length > 0) && !c.pin) {
        acc.violate(BLOCK_REGIONS, false, 0);
        return finish(c, acc);
      }
      const c2 = rm.grid.cell * rm.grid.cell;
      acc.add("straddle", (w.straddle * (sp.straddle() * c2)) / em2);
      acc.add("foreign", (w.foreign * (sp.foreign * c2)) / em2);
    }
    // 4. leaders
    for (const l of c.leaders) {
      this.leaderTerms(i, l, r, c.kind === Kind.Fan || c.kind === Kind.Boundary, acc);
      if (acc.unusable(quick)) return finish(c, acc);
    }
    if (!acc.relaxed) return finish(c, acc);
    // 5. position
    acc.add("position", (w.position * c.rank) / 8);
    // 6. distance from own shape (the rule of step 2 measured it already)
    const gap = c.kind === Kind.Internal ? 0 : nearRule ? dOwn : item.shape.distRect(r);
    // (a stub is part of the distance, not a leader to a distant label)
    const stub = c.hasStub();
    if (c.leaders.length === 0 || stub) {
      acc.add("distance", (w.distance * gap) / em);
      // inside its area: the room the label lacks and its distance from the pole
      acc.add("distance", w.distance * c.inside);
    }
    // 7. shape penalty
    acc.add("shape", w.shape * v.penalty);
    acc.add("shape", (w.shape * Math.abs(c.angle())) / 180.0);
    // 8. edge proximity
    if (la !== null) {
      const d = minf(minf(r.x0 - la.x0, la.x1 - r.x1), minf(r.y0 - la.y0, la.y1 - r.y1));
      acc.add("edge", w.edge * maxf(0, 1 - maxf(d, 0) / em));
    }
    // 9. ambiguity (the item query above covers the reach of adjacent labels); a stub
    // resolves it
    if (w.ambiguity > 0 && c.kind !== Kind.Internal && !stub) {
      let amb: number;
      if (c.leaders.length > 0) amb = 0.5 * this.ambiguityPoint(i, c.leaders[0]!.port, em);
      else if (gap <= gapGuess) amb = this.ambiguityRectCached(i, r, gap, em);
      else amb = this.ambiguityRect(i, r, gap, em);
      acc.add("ambiguity", w.ambiguity * amb);
    }
    // 10. crowd: with stubs, a label beside its mark that another item's mark comes near, and
    // that has no stub, costs as much as a leader (spec §6.9)
    if (
      model.placement.stubs &&
      !stub &&
      (c.kind === Kind.Adjacent || c.kind === Kind.Slider) &&
      crowded(model, this.obs, item, r, this.buf)
    ) {
      acc.add("crowd", w.leader);
    }
    // 11. stability
    if (w.stability > 0) {
      const b = model.warm.get(item.id);
      if (b !== undefined && b !== null) {
        const d = b.center().dist(r.center());
        // 1 per em up to 1 em, then 1/4 per em up to 5 em: a label that must move goes to
        // a near spot rather than to the best one anywhere
        const tail = minf(1, maxf(0, d / em - 1) * 0.25);
        acc.add("stability", w.stability * (minf(1, d / em) + tail));
      }
    }
    // 12. host cost
    if (this.env.hasCostCallback && this.env.hasCostCallback()) {
      acc.add("user", this.env.extraCost ? this.env.extraCost(item.id, r, c.leaders.length > 0) : 0);
    }
    finish(c, acc);
  }

  /** Ambiguity using the items already queried into `buf`. */
  private ambiguityRectCached(i: number, r: Rect, dOwn: number, em: number): number {
    const reach = dOwn + 0.5 * em;
    let dOther = Infinity;
    const buf = this.buf;
    for (let q = 0; q < buf.len; q++) {
      const j = buf.get(q);
      if (j !== i) dOther = minf(dOther, this.model.items[j]!.shape.distRect(r));
    }
    return dOther < reach ? clampf((dOwn - dOther) / em + 0.5, 0, 1) : 0;
  }

  private ambiguityRect(i: number, r: Rect, dOwn: number, em: number): number {
    const reach = dOwn + 0.5 * em;
    this.obs.itemIndex.query(r.inflate(reach), this.buf);
    return this.ambiguityRectCached(i, r, dOwn, em);
  }

  private ambiguityPoint(i: number, p: P, em: number): number {
    const own = maxf(this.model.items[i]!.shape.signedDistance(p), 0);
    const reach = 2 * em;
    const buf = this.buf;
    this.obs.itemIndex.query(Rect.fromCenter(p, reach, reach), buf);
    let dOther = Infinity;
    for (let q = 0; q < buf.len; q++) {
      const j = buf.get(q);
      if (j !== i) dOther = minf(dOther, maxf(this.model.items[j]!.shape.signedDistance(p), 0));
    }
    return dOther < reach && dOther < own ? clampf(1 - dOther / reach, 0, 1) : 0;
  }

  private leaderTerms(i: number, l: Leader, ownRect: Rect, column: boolean, acc: Acc): void {
    const model = this.model;
    const obs = this.obs;
    const item = model.items[i]!;
    const em = item.em();
    const w = model.weights;
    const dy = obs.dynamic;
    const hw = model.leaders.width * 0.5;
    // a stub (spec §6.9) costs its length, not a leader
    if (l.stub) acc.add("stub", (w.leaderLength * l.len) / em);
    else acc.add("leader", w.leader + (w.leaderLength * l.len) / em + w.bends * l.bends);
    // region borders on the way
    const rm = obs.regions;
    if (rm !== null) acc.add("leader_borders", w.leaderBorders * rm.crossings(l.pts));
    // leaders stay on the canvas
    const ca = obs.leaderArea;
    if (ca !== null && !l.pts.every((p) => ca.containsPoint(p))) {
      acc.violate(BLOCK_EDGE, false, 0);
      if (acc.unusable(this.quick)) return;
    }
    const nseg = l.segCount();
    const nMain = l.pts.length > 0 ? l.pts.length - 1 : 0;
    // ownRect.inflate(-0.5)
    const ox0 = ownRect.x0 + 0.5;
    const oy0 = ownRect.y0 + 0.5;
    const ox1 = ownRect.x1 - 0.5;
    const oy1 = ownRect.y1 - 0.5;
    for (let k = 0; k < nseg; k++) {
      const a = l.segA(k);
      const b = l.segB(k);
      // not through the own shape (skip a tiny start piece for tips/boundary starts)
      const a2 = k === 0 ? a.lerp(b, minf(0.5 / maxf(a.dist(b), 1e-9), 0.5)) : a;
      if ((!item.tip || k > 0) && item.shape.distSegment(a2, b) <= EPS) acc.violate(BLOCK_ITEMS, false, 0);
      // not into the own label except at the port (underline is on the label edge)
      if (k < nMain && segOverlapsRectXY(a.x, a.y, b.x, b.y, ox0, oy0, ox1, oy1)) acc.violate(BLOCK_LABELS, false, 0);
      if (acc.unusable(this.quick)) return;
    }
    // other items: clearance (not from the group's members, and not from a mark that
    // covers the leader's anchor, or a column leader's start: no leader avoids it). A
    // leader must only not cross a mark closer than the clearance to its start when it
    // is a fan or boundary label's (it leaves a crowd of touching marks, in the order of
    // its column) or when that mark touches the box of its own mark (it leaves a spot of
    // touching marks, which no leader could keep the clearance from)
    const clearance = item.len.clearance;
    const buf = this.buf;
    obs.itemIndex.query(l.bbox().inflate(clearance), buf);
    const lowerRule = !dy.leaderLower.equals(dy.leaderItems);
    const own = l.member !== null ? model.items[l.member]! : item;
    const anchor = own.anchor;
    const ownBox = own.shape.bbox();
    const start = l.pts[0]!;
    for (let q = 0; q < buf.len; q++) {
      const j = buf.get(q);
      if (j === i || model.groupRep(j) === i) continue;
      const li = lowerRule && model.isLower(i, j) ? dy.leaderLower : dy.leaderItems;
      if (li.kind === AvoidKind.Ignore) continue;
      const sj = model.items[j]!.shape;
      if (sj.contains(anchor) || (column && sj.contains(start))) continue;
      let dmin = Infinity;
      for (let k = 0; k < nseg; k++) {
        const a = l.segA(k);
        const b = l.segB(k);
        dmin = minf(dmin, sj.distSegmentXY(a.x, a.y, b.x, b.y));
      }
      if (li.kind === AvoidKind.Hard) {
        const crossOnly = sj.signedDistance(start) < clearance && (column || sj.distRect(ownBox) <= EPS);
        const lim = crossOnly ? EPS : clearance - EPS;
        if (dmin < lim) {
          acc.violate(BLOCK_ITEMS, false, 0);
          if (acc.unusable(this.quick)) return;
        }
      } else if (dmin < clearance) {
        const f = clearance > 0 ? 1 - dmin / clearance : 1;
        acc.add("leader:items", li.w * f);
      }
    }
    // static classes
    let primIdsLoaded = false;
    const classes = obs.classes;
    for (let ci = 0; ci < classes.length; ci++) {
      const cl = classes[ci]!;
      const sat = cl.sat;
      if (sat === null) continue;
      const lk = cl.leader.kind;
      if (lk === AvoidKind.Hard) {
        let hit = false;
        if (cl.hasRaster) {
          for (let k = 0; k < nseg && !hit; k++) hit = obs.coveredLen(sat, l.segA(k), l.segB(k)) > 0;
        } else if (cl.hasPrims) {
          const buf2 = this.buf2;
          if (!primIdsLoaded) {
            obs.primIndex().query(l.bbox().inflate(hw + 1), buf2);
            primIdsLoaded = true;
          }
          const prims = obs.prims();
          for (let q = 0; q < buf2.len && !hit; q++) {
            const pr = prims[buf2.get(q)]!;
            if (pr[0] !== ci) continue;
            for (let k = 0; k < nseg; k++) {
              const a = l.segA(k);
              const b = l.segB(k);
              if (primDistSegment(pr[1], a, b) < hw - EPS || (hw <= EPS && primDistSegment(pr[1], a, b) <= EPS)) {
                hit = true;
                break;
              }
            }
          }
        }
        if (hit) {
          let sum = -0;
          for (let k = 0; k < nseg; k++) sum += obs.coveredLen(sat, l.segA(k), l.segB(k));
          const extra = sum / em;
          acc.violate(ci, cl.relaxable, model.degrade.softOverlapWeight * extra);
          if (acc.unusable(this.quick)) return;
        }
      } else if (lk === AvoidKind.Soft) {
        let cov = -0;
        for (let k = 0; k < nseg; k++) cov += obs.coveredLen(sat, l.segA(k), l.segB(k));
        acc.addNamed("leader:", cl.name, (cl.leader.w * cov) / em);
      }
    }
  }
}
